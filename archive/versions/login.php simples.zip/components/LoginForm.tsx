import React, { useState, useRef, useEffect } from 'react';

interface LoginFormProps {
  onLogin: (email: string) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [step, setStep] = useState<'email' | 'password'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [step, history]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const value = e.currentTarget.value;
      
      if (!value.trim()) return;

      if (step === 'email') {
        if (!value.includes('@') || !value.includes('.')) {
          setError('Error: Invalid email format detected.');
          return;
        }
        setHistory(prev => [...prev, value]);
        setEmail(value);
        setStep('password');
        setError(null);
      } else {
        setHistory(prev => [...prev, '••••••••••••']);
        setPassword(value);
        setError(null);
        setTimeout(() => {
           onLogin(email);
        }, 500);
      }
    }
  };

  const handleContainerClick = () => {
    if (inputRef.current) inputRef.current.focus();
  }

  // A cleaner, more intuitive prompt
  const Prompt = () => (
    <span className="mr-3 whitespace-nowrap font-medium">
      <span className="text-blue-400">dev</span>
      <span className="text-gray-500">@</span>
      <span className="text-purple-400">devpath</span>
      <span className="text-gray-500">:</span>
      <span className="text-yellow-400">~</span>
      <span className="text-gray-400">$</span>
    </span>
  );

  return (
    <div className="flex flex-col w-full h-full" onClick={handleContainerClick}>
      {/* History */}
      {history.map((line, idx) => (
        <div key={idx} className="mb-2 flex items-center">
             <div className="opacity-50 select-none mr-2">➜</div>
             <span className="text-gray-400 mr-2">
                {idx % 2 === 0 ? 'Enter email:' : 'Enter password:'}
             </span>
             <span className="text-white">{line}</span>
        </div>
      ))}

      {/* Error Message */}
      {error && (
        <div className="text-red-400 mb-2 flex items-center">
          <span className="mr-2">⚠</span> {error}
        </div>
      )}

      {/* Active Input Line */}
      <div className="flex flex-col mt-2 text-dev-text">
        <div className="flex items-center flex-wrap">
            <Prompt />
            <div className="relative flex-1 min-w-[200px] flex items-center">
                <span className="text-gray-400 mr-3 hidden md:inline-block">
                    {step === 'email' ? '(enter email)' : '(enter password)'}
                </span>
                <input
                ref={inputRef}
                type={step === 'email' ? 'text' : 'password'}
                className="flex-1 bg-transparent border-none outline-none text-white caret-transparent font-mono p-0 m-0"
                autoComplete="off"
                autoFocus
                placeholder={step === 'email' ? "type your email..." : "type your password..."}
                value={step === 'email' ? (error && email !== '' ? '' : undefined) : (error && password !== '' ? '' : undefined)}
                onKeyDown={handleKeyDown}
                />
                <div className="animate-blink bg-gray-400 w-2.5 h-5 inline-block align-middle ml-1 rounded-sm" />
            </div>
        </div>
      </div>
    </div>
  );
};