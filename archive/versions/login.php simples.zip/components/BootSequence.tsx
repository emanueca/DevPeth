import React, { useState, useEffect, useRef } from 'react';
import { BootLine } from '../types';

interface BootSequenceProps {
  onComplete: () => void;
}

// ASCII Art with Coffee Mug - Gray Theme
const LOGO_ART = `
      (  )   (   )  )
       ) (   )  (  (
       ..........
     |            |]     DEVPATH
     |            |      ----------
     |   D_PATH   |      Issue Tracker
      \\__________/       v2.4.0
`;

export const BOOT_SEQUENCE: BootLine[] = [
  { text: LOGO_ART, delay: 1000, type: 'code' },
  { text: 'Initializing developer environment...', delay: 300, type: 'output' },
  { text: 'Loading caffeine modules...', delay: 300, type: 'output' },
  { text: '[SUCCESS] Coffee brewed (Dark Roast)', delay: 200, type: 'code' },
  { text: 'Mounting repository file systems...', delay: 400, type: 'output' },
  { text: 'Checking git configuration...', delay: 200, type: 'output' },
  { text: '   > user.name configured', delay: 100, type: 'comment' },
  { text: '   > user.email configured', delay: 100, type: 'comment' },
  { text: 'Connecting to DevPath secure cloud...', delay: 500, type: 'output' },
  { text: 'Handshake accepted.', delay: 200, type: 'code' },
  { text: '', delay: 300, type: 'output' },
  { text: 'Welcome back, Developer.', delay: 800, type: 'code' },
  { text: 'Please authenticate to view your issues.', delay: 100, type: 'output' },
  { text: '', delay: 100, type: 'output' },
];

export const BootSequence: React.FC<BootSequenceProps> = ({ onComplete }) => {
  const [displayedLines, setDisplayedLines] = useState<BootLine[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    let mounted = true;

    const processNextLine = () => {
      if (!mounted) return;
      if (currentIndex >= BOOT_SEQUENCE.length) {
        setTimeout(onComplete, 500);
        return;
      }

      const line = BOOT_SEQUENCE[currentIndex];
      setDisplayedLines(prev => [...prev, line]);
      currentIndex++;

      if (scrollRef.current) {
        scrollRef.current.scrollIntoView({ behavior: 'smooth' });
      }

      setTimeout(processNextLine, line.delay);
    };

    const initialTimer = setTimeout(processNextLine, 200);

    return () => {
      mounted = false;
      clearTimeout(initialTimer);
    };
  }, [onComplete]);

  return (
    <div className="flex flex-col pb-4 w-full font-mono">
      {displayedLines.map((line, index) => {
        const isAscii = line.text.includes('D_PATH');
        const isSuccess = line.text.includes('[SUCCESS]') || line.text.includes('Welcome');
        const isComment = line.type === 'comment';

        return (
          <div key={index} className={`${
            isAscii ? 'text-gray-400 font-bold leading-none mb-6 whitespace-pre overflow-hidden' :
            isSuccess ? 'text-green-400' :
            isComment ? 'text-dev-muted italic' :
            'text-dev-text'
          } mb-1`}>
            {line.text}
          </div>
        );
      })}
      <div ref={scrollRef} />
    </div>
  );
};