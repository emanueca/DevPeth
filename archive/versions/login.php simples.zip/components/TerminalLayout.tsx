import React, { ReactNode } from 'react';

interface TerminalLayoutProps {
  children: ReactNode;
  title?: string;
  isMaximized?: boolean;
  onClose?: () => void;
  onMaximize?: () => void;
  onMinimize?: () => void;
}

export const TerminalLayout: React.FC<TerminalLayoutProps> = ({ 
    children, 
    title = "dev@devpath", 
    isMaximized = false,
    onClose,
    onMaximize,
    onMinimize
}) => {
  return (
    <div className={`flex items-center justify-center font-mono relative transition-all duration-300 ${isMaximized ? 'h-screen p-0 bg-dev-terminal' : 'min-h-screen p-4'}`}>
      
      {/* Main Terminal Window */}
      <div className={`
            flex flex-col bg-dev-terminal border-gray-700/30 overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.3)]
            transition-all duration-300 ease-in-out
            ${isMaximized ? 'w-full h-full rounded-none border-none' : 'w-full max-w-4xl h-[80vh] rounded-xl border'}
      `}>
        
        {/* Title Bar - Modern Clean Style */}
        <div className="bg-dev-header px-4 py-3 flex items-center justify-between select-none border-b border-black/20">
          {/* Traffic Lights */}
          <div className="flex space-x-2 group">
            <button 
                onClick={onClose}
                className="w-3 h-3 rounded-full bg-[#ff5f56] hover:bg-[#ff5f56]/80 transition-colors shadow-sm cursor-pointer flex items-center justify-center"
                title="Close"
            >
            </button>
            <button 
                onClick={onMaximize}
                className="w-3 h-3 rounded-full bg-[#ffbd2e] hover:bg-[#ffbd2e]/80 transition-colors shadow-sm cursor-pointer"
                title="Maximize"
            ></button>
            <button 
                onClick={onMinimize}
                className="w-3 h-3 rounded-full bg-[#27c93f] hover:bg-[#27c93f]/80 transition-colors shadow-sm cursor-pointer"
                title="Restore"
            ></button>
          </div>
          
          {/* Title */}
          <div className="text-gray-400 text-sm font-medium flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3" />
            </svg>
            {title}
          </div>
          
          {/* Empty spacer for balance */}
          <div className="w-14"></div>
        </div>

        {/* Terminal Content Area */}
        <div className="flex-1 p-6 overflow-y-auto text-dev-text text-sm md:text-base leading-relaxed">
            {children}
        </div>
      </div>
    </div>
  );
};