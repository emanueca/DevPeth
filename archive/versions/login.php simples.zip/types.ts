export enum AppState {
  BOOTING = 'BOOTING',
  STATIC_TERMINAL = 'STATIC_TERMINAL',
  LOGIN = 'LOGIN',
  AUTHENTICATED = 'AUTHENTICATED'
}

export interface BootLine {
  text: string;
  delay: number; // ms to wait before showing next line
  type: 'code' | 'output' | 'comment' | 'html';
}

export interface UserCredentials {
  email: string;
  password: string;
}