import React, { useState, useEffect } from 'react';
import { TerminalLayout } from './components/TerminalLayout';
import { BootSequence } from './components/BootSequence';
import { StaticBootView } from './components/StaticBootView';
import { LoginForm } from './components/LoginForm';
import { BinaryArt } from './components/BinaryArt';
import { AppState } from './types';

type WindowMode = 'normal' | 'maximized' | 'closed';

function App() {
  const [appState, setAppState] = useState<AppState>(AppState.BOOTING);
  const [userEmail, setUserEmail] = useState<string>('');
  const [windowMode, setWindowMode] = useState<WindowMode>('normal');
  const [dashboardLoaded, setDashboardLoaded] = useState(false);

  const handleBootComplete = () => {
    setAppState(AppState.LOGIN);
  };

  const handleLogin = (email: string) => {
    setUserEmail(email);
    setAppState(AppState.AUTHENTICATED);
    // Start 5s timer for Homebrew packages
    setTimeout(() => {
        setDashboardLoaded(true);
    }, 5000);
  };

  // Red Button Logic: Close window
  const handleClose = () => {
    setWindowMode('closed');
  };

  // Yellow Button Logic: Toggle Maximize/Restore
  const handleMaximizeToggle = () => {
    setWindowMode(prev => prev === 'maximized' ? 'normal' : 'maximized');
  };

  // Green Button Logic: Go to Static Boot Screen (System Logs/Packages)
  const handleGreenButton = () => {
    setWindowMode('normal'); // Ensure window is open
    setAppState(AppState.STATIC_TERMINAL);
  };

  // System Reboot: Resets everything to initial state
  const handleReboot = () => {
    setAppState(AppState.BOOTING); 
    setWindowMode('normal'); 
    setUserEmail(''); 
    setDashboardLoaded(false);
  };

  // Render the "Closed" state (Art on black background)
  if (windowMode === 'closed') {
    return (
        <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
            <BinaryArt />
            <div className="mt-4">
                <button 
                    onClick={handleReboot}
                    className="text-gray-500 hover:text-white text-xs font-mono border border-gray-800 hover:border-gray-500 px-4 py-2 rounded transition-all cursor-pointer"
                >
                    System Reboot
                </button>
            </div>
        </div>
    );
  }

  return (
    <TerminalLayout 
        title={appState === AppState.BOOTING || appState === AppState.STATIC_TERMINAL ? "devpath-init" : `dev@devpath: ~`}
        isMaximized={windowMode === 'maximized'}
        onClose={handleClose}
        onMaximize={handleMaximizeToggle}
        onMinimize={handleGreenButton}
    >
      
      {appState === AppState.BOOTING && (
        <BootSequence onComplete={handleBootComplete} />
      )}

      {appState === AppState.STATIC_TERMINAL && (
        <StaticBootView onReboot={handleReboot} />
      )}

      {appState === AppState.LOGIN && (
        <LoginForm onLogin={handleLogin} />
      )}

      {appState === AppState.AUTHENTICATED && !dashboardLoaded && (
        <div className="flex items-center text-dev-text">
            <span>Loading Homebrew packages... (5s)</span>
            <div className="animate-blink bg-gray-400 w-2.5 h-5 ml-2 rounded-sm" />
        </div>
      )}

      {appState === AppState.AUTHENTICATED && dashboardLoaded && (
        <div className="animate-fade-in">
          <div className="text-green-400 text-lg mb-4 font-bold flex items-center">
            <span className="mr-2">✔</span> Access Granted
          </div>
          <div className="text-dev-text">
            <p className="mb-4">Welcome back, <span className="text-blue-400">{userEmail}</span>.</p>
            
            <div className="border border-gray-700 rounded p-4 mb-4 bg-black/20">
                <p className="text-gray-400 text-sm mb-2">System Status:</p>
                <div className="flex items-center gap-4">
                     <span className="flex items-center gap-2 text-sm"><div className="w-2 h-2 rounded-full bg-green-500"></div> All Systems Operational</span>
                     <span className="flex items-center gap-2 text-sm"><div className="w-2 h-2 rounded-full bg-yellow-500"></div> Issues: 0 Pending</span>
                </div>
            </div>

            <p className="mt-8 text-gray-500 text-sm italic">
                (Dashboard loading modules... Please wait...)
            </p>
             <div className="mt-2 w-64 h-1 bg-gray-700 rounded overflow-hidden">
                <div className="h-full bg-blue-500 w-1/3 animate-ping origin-left"></div>
            </div>
          </div>
        </div>
      )}

    </TerminalLayout>
  );
}

export default App;