import React, { useState, useRef, useEffect } from 'react';

interface LoginFormProps {
  onLogin: (email: string) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onLogin }) => {
  const [step, setStep] = useState<'email' | 'password'>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Initialize history with the error message from the previous boot step
  const [history, setHistory] = useState<string[]>([
     // Using a special format to be rendered differently in the map
     '__MSG_ERROR__[ERROR] Login session not found.', 
     '__MSG_INFO__To create an account, type "register".'
  ]);
  
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, [step, history]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const value = e.currentTarget.value.trim();
      
      if (!value) return;

      if (step === 'email') {
        // Handle "register" command
        if (value.toLowerCase() === 'register') {
            setHistory(prev => [...prev, value]);
            setHistory(prev => [...prev, '__MSG_SUCCESS__Initializing registration protocol...']);
            // Clears input, stays on email step but effectively "restarts" visually
            e.currentTarget.value = ''; 
            setError(null);
            return;
        }

        if (!value.includes('@') || !value.includes('.')) {
          setError('Error: Invalid email format detected.');
          return;
        }
        setHistory(prev => [...prev, value]);
        setEmail(value);
        setStep('password');
        setError(null);
      } else {
        setHistory(prev => [...prev, '••••••••••••']);
        setPassword(value);
        setError(null);
        setTimeout(() => {
           onLogin(email);
        }, 500);
      }
    }
  };

  const handleContainerClick = () => {
    if (inputRef.current) inputRef.current.focus();
  }

  // A cleaner, more intuitive prompt
  const Prompt = () => (
    <span className="mr-3 whitespace-nowrap font-medium">
      <span className="text-blue-400">dev</span>
      <span className="text-gray-500">@</span>
      <span className="text-purple-400">devpath</span>
      <span className="text-gray-500">:</span>
      <span className="text-yellow-400">~</span>
      <span className="text-gray-400">$</span>
    </span>
  );

  return (
    <div className="flex flex-col w-full h-full" onClick={handleContainerClick}>
      {/* History */}
      {history.map((line, idx) => {
        if (line.startsWith('__MSG_ERROR__')) {
             return <div key={idx} className="text-red-400 mb-1">{line.replace('__MSG_ERROR__', '')}</div>
        }
        if (line.startsWith('__MSG_INFO__')) {
            return <div key={idx} className="text-dev-text mb-4">{line.replace('__MSG_INFO__', '')}</div>
        }
        if (line.startsWith('__MSG_SUCCESS__')) {
            return <div key={idx} className="text-green-400 mb-2">{line.replace('__MSG_SUCCESS__', '')}</div>
        }

        return (
            <div key={idx} className="mb-2 flex items-center">
                <div className="opacity-50 select-none mr-2">➜</div>
                <span className="text-gray-400 mr-2">
                    {/* Logic: if it's the last user entry and we are at password step, it was the email entry. 
                        This is a simple visual approximation. */}
                    Input:
                </span>
                <span className="text-white">{line}</span>
            </div>
        );
      })}

      {/* Error Message */}
      {error && (
        <div className="text-red-400 mb-2 flex items-center">
          <span className="mr-2">⚠</span> {error}
        </div>
      )}

      {/* Active Input Line */}
      <div className="flex flex-col mt-2 text-dev-text">
        <div className="flex items-center flex-wrap">
            <Prompt />
            <div className="relative flex-1 min-w-[200px] flex items-center">
                <span className="text-gray-400 mr-3 hidden md:inline-block">
                    {step === 'email' ? '(enter email or "register")' : '(enter password)'}
                </span>
                <input
                ref={inputRef}
                type={step === 'email' ? 'text' : 'password'}
                className="flex-1 bg-transparent border-none outline-none text-white caret-transparent font-mono p-0 m-0"
                autoComplete="off"
                autoFocus
                placeholder={step === 'email' ? "command or email..." : "password..."}
                value={step === 'email' ? (error && email !== '' ? '' : undefined) : (error && password !== '' ? '' : undefined)}
                onKeyDown={handleKeyDown}
                />
                <div className="animate-blink bg-gray-400 w-2.5 h-5 inline-block align-middle ml-1 rounded-sm" />
            </div>
        </div>
      </div>
    </div>
  );
};