import React, { useState, useRef, useEffect } from 'react';
import { BOOT_SEQUENCE } from './BootSequence';

interface StaticBootViewProps {
  onReboot: () => void;
}

export const StaticBootView: React.FC<StaticBootViewProps> = ({ onReboot }) => {
  const [inputValue, setInputValue] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
    if (scrollRef.current) {
        scrollRef.current.scrollIntoView();
    }
  }, [commandHistory]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const cmd = inputValue.trim().toLowerCase();
      
      if (cmd === 'reboot') {
        onReboot();
      } else {
        setCommandHistory(prev => [...prev, inputValue]);
        setInputValue('');
      }
    }
  };

  const handleClick = () => {
    if (inputRef.current) inputRef.current.focus();
  };

  return (
    <div className="flex flex-col pb-4 w-full font-mono min-h-full" onClick={handleClick}>
      {/* Render the static boot sequence */}
      {BOOT_SEQUENCE.map((line, index) => {
        // Handle Custom Contributors Line
        if (line.text === 'CONTRIBUTORS_LINE') {
            return (
                <div key={`static-${index}`} className="mb-1 text-dev-text pl-4">
                    <span className="text-blue-500">emanueca</span>
                    <span className="text-gray-500">, </span>
                    <span className="text-cyan-400">teste1</span>
                    <span className="text-gray-500">, </span>
                    <span className="text-cyan-400">teste2</span>
                </div>
            );
        }

        const isLogo = line.text.includes('D_PATH');
        const isWelcome = line.text.includes('__          __');
        const isSuccess = line.text.includes('[SUCCESS]');
        const isComment = line.type === 'comment';

        return (
          <div key={`static-${index}`} className={`${
             isLogo ? 'text-gray-400 font-bold leading-none mb-6 whitespace-pre overflow-hidden' :
             isWelcome ? 'text-blue-500 font-bold leading-none mb-6 whitespace-pre overflow-hidden' :
             isSuccess ? 'text-green-400' :
             isComment ? 'text-dev-muted italic pl-3' :
             'text-dev-text'
          } mb-1`}>
            {line.text}
          </div>
        );
      })}

      <div className="text-red-400 mb-1">[ERROR] Login session not found.</div>
      <div className="text-dev-text mb-2">To create an account, type "register".</div>

      {/* Render failed commands history */}
      {commandHistory.map((cmd, idx) => (
         <div key={`err-${idx}`}>
            <div className="flex items-center text-dev-text">
                <span className="text-red-400 mr-2 whitespace-nowrap">root@devpath (type 'reboot' to return)#</span>
                <span>{cmd}</span>
            </div>
            <div className="text-dev-muted mb-1">bash: {cmd}: command not found. (try 'reboot')</div>
         </div>
      ))}

      {/* Input Prompt */}
      <div className="flex items-center mt-2">
        <span className="text-red-400 mr-2 font-bold whitespace-nowrap">root@devpath (type 'reboot' to return)#</span>
        <input
            ref={inputRef}
            type="text"
            className="flex-1 bg-transparent border-none outline-none text-white caret-transparent font-mono p-0 m-0"
            autoComplete="off"
            autoFocus
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyDown}
        />
        <div className="animate-blink bg-gray-400 w-2.5 h-5 inline-block align-middle ml-1 rounded-sm" />
      </div>
      <div ref={scrollRef} />
    </div>
  );
};