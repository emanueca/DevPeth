import React, { useState, useEffect, useRef } from 'react';
import { BootLine } from '../types';

interface BootSequenceProps {
  onComplete: () => void;
}

// ASCII Art with Coffee Mug - Gray Theme
const LOGO_ART = `
      (  )   (   )  )
       ) (   )  (  (
       ..........
     |            |]     Dev Path | communitybr
     |            |      --> Issue & Hardware Exchange
     |   D_PATH   |      --> alphav0.0
      \\__________/
`;

const WELCOME_ART = `
 __          __  _
 \\ \\        / / | |
  \\ \\  /\\  / /__| | ___ ___  _ __ ___   ___
   \\ \\/  \\/ / _ \\ |/ __/ _ \\| '_ \` _ \\ / _ \\
    \\  /\\  /  __/ | (_| (_) | | | | | |  __/
     \\/  \\/ \\___|_|\\___\\___/|_| |_| |_|\\___|
`;

export const BOOT_SEQUENCE: BootLine[] = [
  { text: LOGO_ART, delay: 1000, type: 'code' },
  { text: '[SUCCESS] System loaded', delay: 200, type: 'output' },
  { text: '[SUCCESS] Server connection established', delay: 200, type: 'output' },
  { text: 'Establishing contributor link...', delay: 400, type: 'output' },
  { text: 'CONTRIBUTORS_LINE', delay: 500, type: 'html' }, // Marker for custom rendering
  { text: '> /devpath/banned: No', delay: 100, type: 'comment' },
  { text: '> Server: Online', delay: 100, type: 'comment' },
  { text: 'Connecting...', delay: 600, type: 'output' },
  { text: WELCOME_ART, delay: 1000, type: 'code' },
  { text: '', delay: 500, type: 'output' },
];

export const BootSequence: React.FC<BootSequenceProps> = ({ onComplete }) => {
  const [displayedLines, setDisplayedLines] = useState<BootLine[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    let mounted = true;

    const processNextLine = () => {
      if (!mounted) return;
      if (currentIndex >= BOOT_SEQUENCE.length) {
        setTimeout(onComplete, 500);
        return;
      }

      const line = BOOT_SEQUENCE[currentIndex];
      setDisplayedLines(prev => [...prev, line]);
      currentIndex++;

      if (scrollRef.current) {
        scrollRef.current.scrollIntoView({ behavior: 'smooth' });
      }

      setTimeout(processNextLine, line.delay);
    };

    const initialTimer = setTimeout(processNextLine, 200);

    return () => {
      mounted = false;
      clearTimeout(initialTimer);
    };
  }, [onComplete]);

  return (
    <div className="flex flex-col pb-4 w-full font-mono">
      {displayedLines.map((line, index) => {
        // Handle Custom Contributors Line
        if (line.text === 'CONTRIBUTORS_LINE') {
            return (
                <div key={index} className="mb-1 text-dev-text pl-4">
                    <span className="text-blue-500">emanueca</span>
                    <span className="text-gray-500">, </span>
                    <span className="text-cyan-400">teste1</span>
                    <span className="text-gray-500">, </span>
                    <span className="text-cyan-400">teste2</span>
                </div>
            );
        }

        const isLogo = line.text.includes('D_PATH');
        const isWelcome = line.text.includes('__          __');
        const isSuccess = line.text.includes('[SUCCESS]');
        const isComment = line.type === 'comment';

        return (
          <div key={index} className={`${
            isLogo ? 'text-gray-400 font-bold leading-none mb-6 whitespace-pre overflow-hidden' :
            isWelcome ? 'text-blue-500 font-bold leading-none mb-6 whitespace-pre overflow-hidden' :
            isSuccess ? 'text-green-400' :
            isComment ? 'text-dev-muted italic pl-3' :
            'text-dev-text'
          } mb-1`}>
            {line.text}
          </div>
        );
      })}
      <div ref={scrollRef} />
    </div>
  );
};